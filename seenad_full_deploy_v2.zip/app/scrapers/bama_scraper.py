from __future__ import annotations

import logging
import os
import random
import re
import time
from dataclasses import dataclass
from decimal import Decimal
from typing import Any
from urllib.parse import parse_qs, urlparse

from playwright.sync_api import Browser, BrowserContext, Page, sync_playwright
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import ScrapedListing


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; rv:124.0) Gecko/20100101 Firefox/124.0",
]


PERSIAN_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")
CHROMIUM_CANDIDATE_PATHS = [
    os.getenv("CHROMIUM_EXECUTABLE_PATH"),
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
]


@dataclass
class BamaListing:
    external_id: str
    price: Decimal | None
    year: int | None
    mileage: int | None
    body_condition: str | None
    title: str | None
    url: str
    city: str | None
    raw_data: dict[str, Any]


@dataclass
class BamaScrapeResult:
    processed_count: int
    cards_found: int
    sample_listing: dict[str, Any] | None


def _human_delay(min_seconds: float = 2.0, max_seconds: float = 5.0) -> None:
    time.sleep(random.uniform(min_seconds, max_seconds))


def _to_english_digits(value: str) -> str:
    return value.translate(PERSIAN_DIGITS)


def _extract_int(value: str | None) -> int | None:
    if not value:
        return None
    text = _to_english_digits(value)
    digits = re.sub(r"[^\d]", "", text)
    if not digits:
        return None
    return int(digits)


def _extract_price(value: str | None) -> Decimal | None:
    extracted = _extract_int(value)
    if extracted is None:
        return None
    return Decimal(extracted)


def _extract_external_id(listing_url: str, fallback: str) -> str:
    parsed = urlparse(listing_url)
    query_data = parse_qs(parsed.query)
    for key in ("id", "ad", "listingId", "uid"):
        if key in query_data and query_data[key]:
            return query_data[key][0]

    last_segment = parsed.path.rstrip("/").split("/")[-1]
    if last_segment:
        return last_segment
    return fallback


def _build_context(browser: Browser) -> BrowserContext:
    selected_ua = random.choice(USER_AGENTS)
    return browser.new_context(user_agent=selected_ua, viewport={"width": 1440, "height": 900})


def _resolve_chromium_executable_path() -> str | None:
    for path in CHROMIUM_CANDIDATE_PATHS:
        if path and os.path.exists(path):
            return path
    return None


def _safe_text(locator: Any) -> str | None:
    try:
        text = locator.first.inner_text(timeout=2000).strip()
    except Exception:
        return None
    return text or None


def _extract_cards(page: Page) -> list[Any]:
    selectors = [
        "article",
        ".bama-ad",
        ".search-listing-card",
        '[data-testid*="listing"]',
    ]
    for selector in selectors:
        cards = page.locator(selector)
        if cards.count() > 0:
            return [cards.nth(index) for index in range(cards.count())]
    return []


def _load_listing_cards(page: Page, min_cards: int, logger: logging.Logger | None = None) -> list[Any]:
    max_cycles = 15
    previous_count = 0
    stable_cycles = 0

    for cycle in range(1, max_cycles + 1):
        cards = _extract_cards(page)
        current_count = len(cards)
        if logger:
            logger.info("Scroll cycle %s: detected %s cards", cycle, current_count)
        if current_count >= min_cards:
            return cards

        load_more = page.get_by_role("button", name=re.compile(r"مشاهده بیشتر|Load More", re.IGNORECASE))
        if load_more.count() > 0:
            try:
                load_more.first.click(timeout=3000)
                if logger:
                    logger.info("Clicked 'مشاهده بیشتر' button.")
            except Exception:
                if logger:
                    logger.warning("Could not click 'مشاهده بیشتر' button, fallback to scroll.")
        else:
            page.mouse.wheel(0, 5000)
            page.evaluate("window.scrollBy(0, document.body.scrollHeight)")

        _human_delay(2.5, 5.5)
        page.wait_for_timeout(1200)

        if current_count == previous_count:
            stable_cycles += 1
            if stable_cycles >= 3:
                break
        else:
            stable_cycles = 0
        previous_count = current_count

    return _extract_cards(page)


def _parse_card(card: Any, index: int) -> BamaListing | None:
    href = card.locator("a").first.get_attribute("href")
    if not href:
        return None

    url = href if href.startswith("http") else f"https://bama.ir{href}"
    external_id = _extract_external_id(url, fallback=f"bama-{index}")

    title = _safe_text(card.locator("h2, h3, [class*='title']"))
    price_text = _safe_text(card.locator("[class*='price'], [data-testid*='price']"))
    mileage_text = _safe_text(card.locator("[class*='mileage'], [class*='km'], [data-testid*='mileage']"))
    year_text = _safe_text(card.locator("[class*='year'], [data-testid*='year']"))
    body_text = _safe_text(card.locator("[class*='body'], [class*='condition'], [data-testid*='body']"))
    city_text = _safe_text(card.locator("[class*='location'], [class*='city'], [data-testid*='location']"))

    raw_data: dict[str, Any] = {
        "source": "bama",
        "title": title,
        "url": url,
        "price_text": price_text,
        "year_text": year_text,
        "mileage_text": mileage_text,
        "body_condition_text": body_text,
    }

    return BamaListing(
        external_id=external_id,
        price=_extract_price(price_text),
        year=_extract_int(year_text),
        mileage=_extract_int(mileage_text),
        body_condition=body_text,
        title=title,
        url=url,
        city=city_text,
        raw_data=raw_data,
    )


def _upsert_listing(db: Session, listing: BamaListing) -> None:
    record = db.scalar(
        select(ScrapedListing).where(
            ScrapedListing.source == "bama",
            ScrapedListing.external_id == listing.external_id,
        )
    )

    payload = {
        "title": listing.title,
        "year": listing.year,
        "body_condition": listing.body_condition,
        "url": listing.url,
        "raw_city": listing.city,
    }

    if record:
        record.price = listing.price
        record.mileage = listing.mileage
        record.city = listing.city
        record.raw_data = {**record.raw_data, **listing.raw_data, **payload}
        return

    db.add(
        ScrapedListing(
            source="bama",
            external_id=listing.external_id,
            price=listing.price,
            mileage=listing.mileage,
            city=listing.city,
            raw_data={**listing.raw_data, **payload},
        )
    )


def scrape_bama_brand(
    db: Session,
    *,
    brand_slug: str = "jac",
    model_slug: str = "j4",
    min_listings: int = 20,
    headless: bool = True,
) -> BamaScrapeResult:
    logger = logging.getLogger(__name__)
    inserted_or_updated = 0
    cards_found = 0
    sample_listing: dict[str, Any] | None = None
    target_url = f"https://bama.ir/car/{brand_slug}/{model_slug}"

    with sync_playwright() as p:
        executable_path = _resolve_chromium_executable_path()
        logger.info("Launching Playwright Chromium. executable_path=%s", executable_path)
        browser = p.chromium.launch(
            headless=headless,
            executable_path=executable_path,
            args=["--disable-dev-shm-usage", "--no-sandbox"],
        )
        context = _build_context(browser)
        page = context.new_page()

        logger.info("Opening Bama listing URL: %s", target_url)
        page.goto(target_url, wait_until="domcontentloaded", timeout=90000)
        _human_delay()

        cards = _load_listing_cards(page, min_cards=min_listings, logger=logger)
        cards_found = len(cards)
        logger.info("Final card count on page: %s", cards_found)

        for index, card in enumerate(cards):
            listing = _parse_card(card, index=index)
            if listing is None:
                logger.debug("Card %s skipped because parsing returned None.", index + 1)
                continue
            _upsert_listing(db, listing)
            inserted_or_updated += 1
            if index < 5:
                logger.info(
                    "Extracted card %s/%s: price=%s year=%s mileage=%s body=%s",
                    index + 1,
                    cards_found,
                    listing.price,
                    listing.year,
                    listing.mileage,
                    listing.body_condition,
                )
            if sample_listing is None:
                sample_listing = {
                    "external_id": listing.external_id,
                    "title": listing.title,
                    "price": str(listing.price) if listing.price is not None else None,
                    "year": listing.year,
                    "mileage": listing.mileage,
                    "body_condition": listing.body_condition,
                    "url": listing.url,
                }
            _human_delay()

        db.commit()
        context.close()
        browser.close()

    return BamaScrapeResult(
        processed_count=inserted_or_updated,
        cards_found=cards_found,
        sample_listing=sample_listing,
    )
